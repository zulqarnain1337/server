#include "../include.h"
#include "util.h"

std::string EscapeString(const char *pStr)
{
    MYSQL* conn = mysql_init(nullptr);

    if (conn == nullptr)
    {
        //std::cerr << "mysql_init failed!" << std::endl;
        return "";
    }

    char *tStr = new char[strlen(pStr)*2+1];

    if (!mysql_real_connect(conn, "localhost", "user", "password", "exclusivebot", 3306, nullptr, 0)) 
    {
        //std::cerr << "Error: mysql_real_connect() failed" << std::endl;
        mysql_close(conn);
        return "";
    }

    mysql_real_escape_string(conn, tStr, pStr, strlen(pStr));
    std::string retStr(tStr);
    delete [] tStr;
    mysql_close(conn);
    return retStr;
}

void util::to_lowercase(std::string &str) {
	std::transform(str.begin(), str.end(), str.begin(), ::tolower);
}

bool util::ValidateLogin(const std::string& user, const std::string& pass) 
{
    MYSQL *conn = mysql_init(nullptr);

    if (conn == nullptr) {
        std::cerr << "mysql_init failed!" << std::endl;
        return false;
    }

    conn = mysql_real_connect(conn, "localhost", "user", "password", "exclusivebot", 3306, nullptr, 0);

    if (conn == nullptr) 
    {
        std::cerr << "mysql_real_connect failed!" << std::endl;
        return false;
    }

    std::string query = "SELECT COUNT(*) FROM users WHERE username = '"
                        + EscapeString(user.c_str()) + "' AND password = '" + EscapeString(pass.c_str()) + "'" 
			+ "AND banned = 0";

    if (mysql_query(conn, query.c_str()) != 0) {
        std::cerr << "mysql_query failed!" << std::endl;
        return false;
    }

    MYSQL_RES *result = mysql_store_result(conn);

    if (result == nullptr) 
    {
        std::cerr << "mysql_store_result failed!" << std::endl;
        return false;
    }

    MYSQL_ROW row = mysql_fetch_row(result);
    int count = std::stoi(row[0]);

    mysql_free_result(result);
    mysql_close(conn);

    return (count > 0);
}


bool util::ValidateHWID(const std::string& gpuDesc, const std::string& gpuGuid, const std::string& mbManufacturer,
                           const std::string& mbModel, const std::string& mbSerialNumber) {
    MYSQL *conn = mysql_init(nullptr);

    if (conn == nullptr) {
        std::cerr << "mysql_init failed!" << std::endl;
        return false;
    }

    conn = mysql_real_connect(conn, "localhost", "user", "password", "exclusivebot", 3306, nullptr, 0);

    if (conn == nullptr) 
    {
        std::cerr << "mysql_real_connect failed!" << std::endl;
        return false;
    }

    std::string query = "SELECT COUNT(*) FROM hardware_ids WHERE gpu_desc = '"
                        + gpuDesc + "' AND gpu_guid = '" + gpuGuid
                        + "' AND mb_manufacturer = '" + mbManufacturer
                        + "' AND mb_model = '" + mbModel
                        + "' AND mb_serialnumber = '" + mbSerialNumber + "'";

    if (mysql_query(conn, query.c_str()) != 0) {
        std::cerr << "mysql_query failed!" << std::endl;
        return false;
    }

    MYSQL_RES *result = mysql_store_result(conn);

    if (result == nullptr) 
    {
        std::cerr << "mysql_store_result failed!" << std::endl;
        return false;
    }

    MYSQL_ROW row = mysql_fetch_row(result);
    int count = std::stoi(row[0]);

    mysql_free_result(result);
    mysql_close(conn);

    return (count > 0);
}

bool util::IsHWIDRegistered(const std::string& user) 
{
    MYSQL *conn = mysql_init(nullptr);

    if (conn == nullptr) {
        std::cerr << "mysql_init failed!" << std::endl;
        return false;
    }

    conn = mysql_real_connect(conn, "localhost", "user", "password", "exclusivebot", 3306, nullptr, 0);

    if (conn == nullptr) 
    {
        std::cerr << "mysql_real_connect failed!" << std::endl;
        return false;
    }

    std::string query = "SELECT COUNT(*) FROM users u JOIN hardware_ids hw_ids ON u.id = hw_ids.id WHERE u.username ='"
                        + user + "'";

    if (mysql_query(conn, query.c_str()) != 0) {
        //std::cerr << "mysql_query failed!" << std::endl;
        mysql_close(conn);
	return false;
    }

    MYSQL_RES *result = mysql_store_result(conn);

    if (result == nullptr) 
    {
        std::cerr << "mysql_store_result failed!" << std::endl;
        return false;
    }

    MYSQL_ROW row = mysql_fetch_row(result);
    int count = std::stoi(row[0]);

    mysql_free_result(result);
    mysql_close(conn);

    return (count > 0);
}

bool util::RegisterHWID(const std::string& gpu_desc, const std::string& gpu_guid, 
                           const std::string& mb_manufacturer, const std::string& mb_model, 
                           const std::string& mb_serialnumber) 
{
    MYSQL *conn = mysql_init(nullptr);
    if (conn == nullptr) {
        //std::cerr << "Error: mysql_init() failed" << std::endl;
        return false;
    }

    if (!mysql_real_connect(conn, "localhost", "user", "password", "exclusivebot", 3306, nullptr, 0)) {
        //std::cerr << "Error: mysql_real_connect() failed" << std::endl;
        mysql_close(conn);
        return false;
    }

    std::string query = "INSERT INTO hardware_ids (gpu_desc, gpu_guid, mb_manufacturer, mb_model, mb_serialnumber) VALUES ('" + EscapeString(gpu_desc.c_str()) + "', '" + EscapeString(gpu_guid.c_str()) + "', '" + EscapeString(mb_manufacturer.c_str()) + "', '" + EscapeString(mb_model.c_str()) + "', '" + EscapeString(mb_serialnumber.c_str()) + "')";

    if (mysql_query(conn, query.c_str()) != 0) {
        //std::cerr << "Error: mysql_query() failed: " << mysql_error(conn) << std::endl;
        mysql_close(conn);
        return false;
    }

    std::string query2 = "INSERT INTO subscriptions (games, expiration_date) VALUES (JSON_ARRAY('Metin2 - Gameforge.com'), UNIX_TIMESTAMP(NOW()))";

    if (mysql_query(conn, query2.c_str()) != 0) {
        //std::cerr << "Error: mysql_query() failed: " << mysql_error(conn) << std::endl;
        mysql_close(conn);
        return false;
    }

    mysql_close(conn);
    return true;
}

bool util::ValidateHWID(const std::string& user, const std::string& gpu_desc, const std::string& gpu_guid, 
                           const std::string& mb_manufacturer, const std::string& mb_model, 
                           const std::string& mb_serialnumber) {
    MYSQL *conn = mysql_init(nullptr);
    if (conn == nullptr) {
        //std::cerr << "Error: mysql_init() failed" << std::endl;
        return false;
    }

    if (!mysql_real_connect(conn, "localhost", "user", "password", "exclusivebot", 3306, nullptr, 0)) {
        //std::cerr << "Error: mysql_real_connect() failed" << std::endl;
        mysql_close(conn);
        return false;
    }

    std::string query = "SELECT COUNT(*) FROM users u JOIN hardware_ids hw_ids ON u.id = hw_ids.id WHERE " "username = '" + EscapeString(user.c_str()) + "' AND " "gpu_desc = '" + EscapeString(gpu_desc.c_str()) 
    + "' AND " "gpu_guid = '" + EscapeString(gpu_guid.c_str()) + "' AND " "mb_manufacturer = '" + EscapeString(mb_manufacturer.c_str()) + "' AND " "mb_model = '" + EscapeString(mb_model.c_str()) 
    + "' AND " "mb_serialnumber = '" + EscapeString(mb_serialnumber.c_str()) + "';";
    
    if (mysql_query(conn, query.c_str()) != 0) {
        //std::cerr << "mysql_query failed!" << std::endl;
        mysql_close(conn);
        return false;
    }

    MYSQL_RES *result = mysql_store_result(conn);

    if (result == nullptr) 
    {
        std::cerr << "mysql_store_result failed!" << std::endl;
        return false;
    }

    MYSQL_ROW row = mysql_fetch_row(result);
    int count = std::stoi(row[0]);

    mysql_free_result(result);
    mysql_close(conn);

    return (count > 0);
}

int util::ValidateSubscription(const std::string& user, const std::string& game) 
{
    MYSQL *conn = mysql_init(nullptr);
    MYSQL_RES *res; // MySQL Result object
    MYSQL_ROW row; // MySQL Row object

    if (conn == nullptr) {
        //std::cerr << "Error: mysql_init() failed" << std::endl;
        return false;
    }

    if (!mysql_real_connect(conn, "localhost", "user", "password", "exclusivebot", 3306, nullptr, 0)) {
        //std::cerr << "Error: mysql_real_connect() failed" << std::endl;
        mysql_close(conn);
        return false;
    }

    //std::string query = "SELECT JSON_EXTRACT(expiration_date, '$[0]') FROM subscriptions subs JOIN users u ON subs.id = u.id WHERE JSON_UNQUOTE(JSON_EXTRACT(expiration_date, '$[0]')) > UNIX_TIMESTAMP(NOW()) AND  JSON_CONTAINS(games, '\"Metin2 - Gameforge.com\"', '$[0]') AND username = '" +  EscapeString(user.c_str()) + "';";
    std::string query = "SELECT JSON_EXTRACT(expiration_date, '$[0]') FROM subscriptions subs "
                    "JOIN users u ON subs.id = u.id "
                    "WHERE JSON_UNQUOTE(JSON_EXTRACT(expiration_date, '$[0]')) > UNIX_TIMESTAMP(NOW()) "
                    "AND JSON_CONTAINS(games, '" + EscapeString(game.c_str()) + "', '$[0]') "
                    "AND username = '" +  EscapeString(user.c_str()) + "';";


    if (mysql_query(conn, query.c_str()) != 0) 
    {
        //std::cerr << "mysql_query failed!" << std::endl;
        mysql_close(conn);
        return -1;
    }

    // Get result
    res = mysql_store_result(conn);

    // Process result
    if (res) 
    {
        // Loop through rows
        while ((row = mysql_fetch_row(res))) 
        {
            // Output data
            // cout << "JSON Extracted Value: " << row[0] << endl;
            return std::atoi(row[0]);
        }

        // Free result
        mysql_free_result(res);
    }

    // Close connection
    mysql_close(conn);

    return -1;
}
