#pragma once
#include <mysql/mysql.h>
#include <iostream>

namespace util 
	{

	void to_lowercase(std::string &str);
	bool ValidateLogin(const std::string& user, const std::string& pass);
	bool ValidateHWID(const std::string& gpuDesc, const std::string& gpuGuid, const std::string& mbManufacturer,
                           const std::string& mbModel, const std::string& mbSerialNumber);
	bool IsHWIDRegistered(const std::string& user);
	bool RegisterHWID(const std::string& gpu_desc, const std::string& gpu_guid,
                           const std::string& mb_manufacturer, const std::string& mb_model,
                           const std::string& mb_serialnumber);
	bool ValidateHWID(const std::string& user, const std::string& gpu_desc, const std::string& gpu_guid, 
                           const std::string& mb_manufacturer, const std::string& mb_model, 
                           const std::string& mb_serialnumber);
};
