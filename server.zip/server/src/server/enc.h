#pragma once

namespace enc {

void encrypt_message(std::string &str);
void decrypt_message(std::string &str);

};  // namespace enc